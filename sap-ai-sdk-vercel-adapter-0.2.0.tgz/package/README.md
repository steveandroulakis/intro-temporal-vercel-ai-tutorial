# SAP AI SDK Vercel Adapter

A Vercel AI SDK provider adapter for SAP Generative AI Hub, enabling seamless integration with the Vercel AI SDK and OpenAI Agents SDK.

## Features

- ✅ **LanguageModelV3 Interface**: Full Vercel AI SDK 6.x compatibility
- ✅ **Multi-Provider Support**: Anthropic Claude, OpenAI GPT, Google Gemini via SAP Gen AI Hub
- ✅ **Tool Calling**: Native function calling via SAP Orchestration
- ✅ **Streaming**: Full SSE streaming support for real-time responses
- ✅ **OAuth 2.0**: Native SAP BTP authentication with automatic token refresh
- ✅ **TypeScript**: Full type safety and IDE support
- ✅ **Agents SDK Compatible**: Works with @openai/agents out of the box

## Architecture

```
@openai/agents → aisdk() → LanguageModelV3 → SAP Orchestration → Gen AI Hub
                    ↓
                MCP Tools (executed by Agents SDK)
```

This adapter provides a **clean LanguageModelV3 interface only**. Tool execution happens at the agent layer via MCP, following the SDK-first principle.

## Installation

```bash
npm install @sap/ai-sdk-vercel-adapter
```

## Quick Start

### Basic Usage with Vercel AI SDK

```typescript
import { createSAPAI } from '@sap/ai-sdk-vercel-adapter';
import { generateText } from 'ai';

// Create provider (reads from env vars)
const sapai = createSAPAI();

// Generate text
const result = await generateText({
  model: sapai.languageModel('anthropic--claude-4.5-sonnet'),
  prompt: 'Hello!',
});

console.log(result.text);
```

### Streaming

```typescript
import { createSAPAI } from '@sap/ai-sdk-vercel-adapter';
import { streamText } from 'ai';

const sapai = createSAPAI();

const result = await streamText({
  model: sapai.languageModel('gpt-5'),
  prompt: 'Write a short poem',
});

for await (const chunk of result.textStream) {
  process.stdout.write(chunk);
}
```

### Tool Calling

```typescript
import { createSAPAI } from '@sap/ai-sdk-vercel-adapter';
import { generateText } from 'ai';
import { z } from 'zod';

const sapai = createSAPAI();

const result = await generateText({
  model: sapai.languageModel('anthropic--claude-4.5-sonnet'),
  prompt: 'What is the weather in San Francisco?',
  tools: {
    getWeather: {
      description: 'Get weather for a location',
      inputSchema: z.object({
        location: z.string().describe('City name'),
      }),
      execute: async ({ location }) => {
        return { temperature: 72, condition: 'sunny' };
      },
    },
  },
});

console.log(result.text);
```

### OpenAI Agents SDK Integration

```typescript
import { createSAPAI } from '@sap/ai-sdk-vercel-adapter';
import { Agent, run } from '@openai/agents';
import { aisdk } from '@openai/agents-extensions';

const sapai = createSAPAI();
const model = aisdk(sapai.languageModel('anthropic--claude-4.5-sonnet'));

const agent = new Agent({
  model,
  name: 'my-agent',
  instructions: 'You are a helpful assistant.',
});

const result = await run(agent, 'What is 2+2?');
console.log(result.finalOutput);
```

### With MCP Tools (Agent Layer)

```typescript
import { createSAPAI } from '@sap/ai-sdk-vercel-adapter';
import { Agent } from '@openai/agents';
import { aisdk } from '@openai/agents-extensions';

const sapai = createSAPAI();
const model = aisdk(sapai.languageModel('anthropic--claude-4.5-sonnet'));

const agent = new Agent({
  model,
  name: 'data-agent',
  instructions: 'You help users query SAP data.',
  mcpServers: [
    {
      url: process.env.SAP_MCP_SERVER_URL,
      apiKey: process.env.SAP_MCP_API_KEY,
    }
  ],
});

// MCP tools are automatically available to the agent
// Tool execution happens in the Agents SDK layer
```

## Environment Variables

### Required

```bash
# Service Key (Base64 encoded recommended for Next.js)
AICORE_SERVICE_KEY_BASE64=eyJjbGllbnRpZCI6...

# OR provide individual credentials
AICORE_CLIENT_ID=your-client-id
AICORE_CLIENT_SECRET=your-client-secret
AICORE_AUTH_URL=https://your-tenant.authentication.sap.hana.ondemand.com/oauth/token
AICORE_BASE_URL=https://api.ai.prod.eu-central-1.aws.ml.hana.ondemand.com

# Orchestration deployment
ORCHESTRATION_DEPLOYMENT_ID=your-deployment-id
```

### Optional

```bash
# Resource group (default: 'default')
AICORE_RESOURCE_GROUP=default

# Debug logging
SAP_AI_VERBOSE=1
SAP_SDK_LOG_LEVEL=debug
```

## Supported Models

The adapter automatically detects the provider from the model ID:

- **Anthropic**: `anthropic--claude-4.5-sonnet`, `claude-*`
- **OpenAI**: `gpt-5`, `gpt-4o`, `gpt-*`
- **Google**: `gemini-2.5-pro`, `gemini-*`

## Telemetry and Optional Logger Injection

This adapter is silent by default. For optional visibility, inject a minimal logger when creating the provider. When no logger is provided, logs only appear if SAP_AI_VERBOSE=1.

Example:
```typescript
import { createSAPAI } from '@sap/ai-sdk-vercel-adapter';

const logger = {
  info: (obj, msg) => console.log('[adapter-info]', msg, obj),
  debug: (obj, msg) => console.log('[adapter-debug]', msg, obj),
  error: (obj, msg) => console.error('[adapter-error]', msg, obj),
};

const sapai = createSAPAI({ logger });
```

Provider metadata returned by non-streaming calls (doGenerate) includes telemetry fields you can log at the host layer:
- modelId: string
- normalizedModelId: string
- deploymentId: string | undefined
- provider: 'anthropic' | 'openai' | 'google' | 'unknown'
- elapsedMs: number
- toolCallsCount: number

Usage tokens are returned in `result.usage`:
- inputTokens
- outputTokens

Log these fields using your structured logger (e.g., Pino) with OpenTelemetry trace context.

## API Reference

### `createSAPAI(settings?)`

Creates a new SAP AI provider instance.

**Parameters:**
- `settings` (optional): Configuration object or omit to use environment variables

**Returns:** `SAPAIProvider`

### `SAPAIProvider.languageModel(modelId)`

Gets a language model instance for the specified model ID.

**Parameters:**
- `modelId`: Model identifier (e.g., 'gpt-5', 'anthropic--claude-4.5-sonnet')

**Returns:** `LanguageModelV3`

### `SAPAIProvider.chat(modelId)`

Alias for `languageModel()`.

## Internal Packaging (Tarball)

For internal GitHub testing, produce a tarball and commit it to a branch:

Steps:
```bash
cd sdk/sap-ai-vercel-adapter
npm pack
# → Outputs: sap-ai-sdk-vercel-adapter-0.1.1.tgz
```

Install the tarball in a consumer project (example: agent-api):
```bash
cd agent-api
npm install ../sdk/sap-ai-vercel-adapter/sap-ai-sdk-vercel-adapter-0.1.1.tgz
```

Note:
- The adapter's package.json defines "prepack" to build automatically before packing.
- Only `dist` and `README.md` are included in the tarball.

## Testing

Run the test suite:

```bash
# Copy environment template
cp .env.example .env
# Edit .env with your credentials

# Run all tests
./run-tests.sh

# Or run individual tests
tsx test-basic.ts        # Basic text generation
tsx test-streaming.ts    # Streaming
tsx test-tools.ts        # Tool calling
tsx test-agents.ts       # Agents SDK integration
```

## Architecture Principles

This adapter follows three core tenets:

1. **AI-Native**: Uses LLM orchestration via SAP Gen AI Hub
2. **SDK-First**: Maximizes use of Vercel AI SDK, SAP AI SDK, and Agents SDK
3. **Real Outcomes**: Delivers working integrations with real SAP data

### What This Adapter Does

- ✅ Implements `LanguageModelV3` interface
- ✅ Handles OAuth authentication
- ✅ Converts messages to SAP Orchestration format
- ✅ Converts tools to SAP Orchestration format
- ✅ Parses responses back to Vercel AI SDK format
- ✅ Supports streaming and non-streaming

### What This Adapter Does NOT Do

- ❌ Execute MCP tools (handled by Agents SDK)
- ❌ Manage agent state (handled by Agents SDK)
- ❌ Custom tool execution logic (use standard SDK patterns)

## Comparison with LiteLLM Approach

| Aspect | LiteLLM Proxy | Native Adapter |
|--------|---------------|----------------|
| **Latency** | +10-40ms (proxy hop) | Direct (no overhead) |
| **Dependencies** | LiteLLM service | None (direct to SAP) |
| **Auth** | API key | OAuth 2.0 |
| **Tool Calling** | Translated | Native |
| **Maintenance** | Two services | One service |
| **Production Ready** | ⚠️ Requires hardening | ✅ Direct integration |

## Troubleshooting

### Authentication Issues

If you see authentication errors:

1. Verify `AICORE_SERVICE_KEY_BASE64` is set correctly
2. Check that the service key JSON is valid
3. Ensure the deployment ID exists and is accessible

### Tool Calling Not Working

1. Verify tools are defined with `inputSchema` (not `parameters`)
2. Check that SAP Orchestration deployment supports tool calling
3. Enable verbose logging: `SAP_AI_VERBOSE=1`

### TypeScript Errors

Make sure you have the correct peer dependencies:

```bash
npm install @ai-sdk/provider @openai/agents @openai/agents-extensions
```

## License

MIT

## Contributing

Contributions welcome! Please open an issue or PR.

## Support

For issues related to:
- **This adapter**: Open a GitHub issue
- **SAP Gen AI Hub**: Contact SAP support
- **Vercel AI SDK**: See [Vercel AI SDK docs](https://sdk.vercel.ai)
- **OpenAI Agents SDK**: See [Agents SDK docs](https://openai.github.io/openai-agents-js/)
